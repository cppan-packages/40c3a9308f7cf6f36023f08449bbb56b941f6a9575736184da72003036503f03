//  Copyright (c) 2016 Hartmut Kaiser
//
//  Distributed under the Boost Software License, Version 1.0. (See accompanying
//  file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#if !defined(HPX_RUN_AS_MAR_12_2016_0227PM)
#define HPX_RUN_AS_MAR_12_2016_0227PM

#include <hpx/runtime/threads/run_as_hpx_thread.hpp>
#include <hpx/runtime/threads/run_as_os_thread.hpp>

#endif
